// Banking form validation and anti-bot measures

// Track user interactions for bot detection
let mouseMovements = 0;
let keystrokes = 0;
let pageLoadTime = Date.now();

document.addEventListener('mousemove', function() {
    mouseMovements++;
});

document.addEventListener('keydown', function() {
    keystrokes++;
});

// Form validation
document.getElementById('loginForm').addEventListener('submit', function(e) {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Basic validation
    if (!username || !password) {
        e.preventDefault();
        alert('Please enter both username and password.');
        return false;
    }
    
    // Bot detection - require minimum interaction
    const timeOnPage = Date.now() - pageLoadTime;
    if (mouseMovements < 3 || keystrokes < 5 || timeOnPage < 5000) {
        // Still allow submission but flag as suspicious
        console.log('Suspicious activity detected');
    }
    
    // Add hidden fields with interaction data
    const interactionData = document.createElement('input');
    interactionData.type = 'hidden';
    interactionData.name = 'interaction_data';
    interactionData.value = JSON.stringify({
        mouse_movements: mouseMovements,
        keystrokes: keystrokes,
        time_on_page: timeOnPage,
        screen_resolution: screen.width + 'x' + screen.height,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
    });
    
    this.appendChild(interactionData);
});

// Credit card number formatting
function formatCardNumber(input) {
    let value = input.value.replace(/\D/g, '');
    value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
    input.value = value;
}

// Expiry date formatting
function formatExpiry(input) {
    let value = input.value.replace(/\D/g, '');
    if (value.length >= 2) {
        value = value.substring(0,2) + '/' + value.substring(2,4);
    }
    input.value = value;
}

// Add event listeners when card verification page loads
document.addEventListener('DOMContentLoaded', function() {
    const cardInput = document.querySelector('input[name="card_number"]');
    const expiryInput = document.querySelector('input[name="expiry"]');
    
    if (cardInput) {
        cardInput.addEventListener('input', function() {
            formatCardNumber(this);
        });
    }
    
    if (expiryInput) {
        expiryInput.addEventListener('input', function() {
            formatExpiry(this);
        });
    }
});